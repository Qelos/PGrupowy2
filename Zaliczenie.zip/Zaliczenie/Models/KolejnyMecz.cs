﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Zaliczenie.Models
{
    public class KolejnyMecz
    {
        [Key]
        public string Gospodarz { get; set; }
        [DataType(DataType.DateTime)]
        public DateTime Data { get; set; }
        public string Gość { get; set; }

    }
}
