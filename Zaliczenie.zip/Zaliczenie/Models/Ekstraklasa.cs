﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Zaliczenie.Models
{
    public class Ekstraklasa
    {
        public List<ObiektSportowy> List_A { get; set; }
        public List<KolejnyMecz> List_B { get; set; }
        public List<Popularne> List_C { get; set; }
    }
}
