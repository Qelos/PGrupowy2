﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace Zaliczenie.Migrations
{
    public partial class Kolejny : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "KolejnyMecz",
                columns: table => new
                {
                    Gospodarz = table.Column<string>(nullable: false),
                    Data = table.Column<DateTime>(nullable: false),
                    Gość = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_KolejnyMecz", x => x.Gospodarz);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "KolejnyMecz");
        }
    }
}
