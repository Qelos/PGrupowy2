﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Zaliczenie.Migrations
{
    public partial class Wiadomosci : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
    name: "News",
    columns: table => new
    {
        Title = table.Column<string>(nullable: false),
        Link = table.Column<string>(nullable: true),
        Img = table.Column<string>(nullable: true)
    },
    constraints: table =>
    {
        table.PrimaryKey("PK_Title", x => x.Title);
    });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
    name: "News");
        }
    }
}
