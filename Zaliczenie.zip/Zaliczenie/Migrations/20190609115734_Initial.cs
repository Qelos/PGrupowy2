﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Zaliczenie.Migrations
{
    public partial class Initial : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Popularne",
                columns: table => new
                {
                    Name = table.Column<string>(nullable: true),
                    Img = table.Column<string>(nullable: true),
                    Link = table.Column<string>(nullable: true),
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Popularne", x => x.Name);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "TPopularne");
        }
    }
}
