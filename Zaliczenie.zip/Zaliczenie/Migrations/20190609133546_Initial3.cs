﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Zaliczenie.Migrations
{
    public partial class Initial3 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "ObiektSportowy",
                columns: table => new
                {
                    Name = table.Column<string>(nullable: false),
                    Link = table.Column<string>(nullable: true),
                    Img = table.Column<string>(nullable: true),
                    Descrition = table.Column<string>(nullable: true),
                    DataDodania = table.Column<string>(nullable:true),
                    Typ = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ObiektSportowy", x => x.Name);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Obiekty");
        }
    }
}
