﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Zaliczenie.Models;

namespace Zaliczenie.Controllers
{
    public class PopularneController : Controller
    {
        private readonly ZaliczenieContext _context;

        public PopularneController(ZaliczenieContext context)
        {
            _context = context;
        }

        // GET: Tabelas
        public async Task<IActionResult> Index()
        {
            var Kolejka = _context.Popularne
                                                .OrderByDescending(m => m.Name);
            return View(await Kolejka.ToListAsync());
        }

        // GET: Tabelas/Details/5
        public async Task<IActionResult> Details(string id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var popularne = await _context.Popularne
                .FirstOrDefaultAsync(m => m.Name == id);
            if (popularne == null)
            {
                return NotFound();
            }

            return View(popularne);
        }

        // GET: Tabelas/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Tabelas/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Name,Img,Link")] Popularne popularne)
        {
            if (ModelState.IsValid)
            {
                _context.Add(popularne);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(popularne);
        }

        // GET: Tabelas/Edit/5
        public async Task<IActionResult> Edit(string id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var popularne = await _context.Popularne.FindAsync(id);
            if (popularne == null)
            {
                return NotFound();
            }
            return View(popularne);
        }

        // POST: Tabelas/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(string id, [Bind("Name,Link,Img")] Popularne popularne)
        {
            if (id != popularne.Name)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(popularne);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!PopularneExists(popularne.Name))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(popularne);
        }

        // GET: Tabelas/Delete/5
        public async Task<IActionResult> Delete(string id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var popularne = await _context.Popularne
                .FirstOrDefaultAsync(m => m.Name == id);
            if (popularne == null)
            {
                return NotFound();
            }

            return View(popularne);
        }

        // POST: Tabelas/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(string id)
        {
            var popularne = await _context.Popularne.FindAsync(id);
            _context.Popularne.Remove(popularne);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool PopularneExists(string id)
        {
            return _context.Popularne.Any(e => e.Name == id);
        }
    }
}
