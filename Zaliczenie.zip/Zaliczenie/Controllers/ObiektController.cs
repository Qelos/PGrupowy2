﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Zaliczenie.Models;

namespace Zaliczenie.Controllers
{
    public class ObiektController : Controller
    {
        private readonly ZaliczenieContext _context;

        public ObiektController(ZaliczenieContext context)
        {
            _context = context;
        }

        // GET: PoprzedniMeczs
        public async Task<IActionResult> Index(string DanyTyp)
        {

            if (!String.IsNullOrEmpty(DanyTyp))
            {
                var obiektSportowy = _context.ObiektSportowy.Where(s => s.Typ.Contains(DanyTyp));
                return View(await obiektSportowy.ToListAsync());
            }
            else
            {
               var obiektSportowy = _context.ObiektSportowy;
                return View(await obiektSportowy.ToListAsync());
            }
                
        }

        // GET: PoprzedniMeczs/Details/5
        public async Task<IActionResult> Details(string id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var obiektSportowy = await _context.ObiektSportowy
                .FirstOrDefaultAsync(m => m.Name == id);
            if (obiektSportowy == null)
            {
                return NotFound();
            }

            return View(obiektSportowy);
        }

        // GET: PoprzedniMeczs/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: PoprzedniMeczs/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Name,Link,Img,Description")] ObiektSportowy obiektSportowy)
        {
            if (ModelState.IsValid)
            {
                _context.Add(obiektSportowy);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(obiektSportowy);
        }

        // GET: PoprzedniMeczs/Edit/5
        public async Task<IActionResult> Edit(string id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var obiektSportowy = await _context.ObiektSportowy.FindAsync(id);
            if (obiektSportowy == null)
            {
                return NotFound();
            }
            return View(obiektSportowy);
        }

        // POST: PoprzedniMeczs/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(string id, [Bind("Gospodarz,Wynik,Gość,Img")] ObiektSportowy obiektSportowy)
        {
            if (id != obiektSportowy.Name)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(obiektSportowy);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!PoprzedniMeczExists(obiektSportowy.Name))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(obiektSportowy);
        }

        // GET: PoprzedniMeczs/Delete/5
        public async Task<IActionResult> Delete(string id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var poprzedniMecz = await _context.ObiektSportowy
                .FirstOrDefaultAsync(m => m.Name == id);
            if (poprzedniMecz == null)
            {
                return NotFound();
            }

            return View(poprzedniMecz);
        }

        // POST: PoprzedniMeczs/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(string id)
        {
            var poprzedniMecz = await _context.ObiektSportowy.FindAsync(id);
            _context.ObiektSportowy.Remove(poprzedniMecz);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool PoprzedniMeczExists(string id)
        {
            return _context.ObiektSportowy.Any(e => e.Name == id);
        }

        public ActionResult Szukaj()
        {
            return View();
        }
    }
}

