﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Zaliczenie.Models;

namespace Zaliczenie.Controllers
{
    public class HomeController : Controller
    {
        private readonly ZaliczenieContext _context;

        public ZaliczenieContext Context => _context;

        public HomeController(ZaliczenieContext context)
        {
            _context = context;
        }
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult About()
        {
            List<ObiektSportowy> obiektSportowy = new List<ObiektSportowy>();
            //List<KolejnyMecz> kolejnyMecz = new List<KolejnyMecz>();
            List<Popularne> popularne = new List<Popularne>();

            obiektSportowy = _context.ObiektSportowy.OrderByDescending(x => x.DataDodania).Take(8).ToList();
            //kolejnyMecz = _context.KolejnyMecz.OrderByDescending(x => x.Data).ToList();
            popularne = _context.Popularne.OrderByDescending(x => x.Name).Take(4).ToList();

            Ekstraklasa FinalItem = new Ekstraklasa()
            {
                List_A = obiektSportowy,
              //  List_B = kolejnyMecz,
                List_C = popularne
            };

            return View(FinalItem);
        }

        public IActionResult Contact()
        {
            ViewData["Message"] = "Your contact page.";

            return View();
        }

        public IActionResult Privacy()
        {
            var Newsy = _context.News.OrderBy(x => x.Date).Take(3);
            return View(Newsy);
        }
        public IActionResult Wiadomosci()
        {
            var Newsy = _context.News.OrderBy(x => x.Date).Take(3);
            return View(Newsy);
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
