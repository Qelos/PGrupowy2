﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Zaliczenie.Models;

namespace Zaliczenie.Models
{
    public class ZaliczenieContext : DbContext
    {
        public ZaliczenieContext (DbContextOptions<ZaliczenieContext> options)
            : base(options)
        {
        }

        public DbSet<Zaliczenie.Models.Popularne> Popularne { get; set; }

        public DbSet<Zaliczenie.Models.KolejnyMecz> KolejnyMecz { get; set; }

        public DbSet<Zaliczenie.Models.ObiektSportowy> ObiektSportowy { get; set; }

        public DbSet<Zaliczenie.Models.News> News { get; set; }
    }
}
